module schooljava {
	requires java.sql;
}
package schooljava;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;


public class DBmanagement {
	
	private final static String driver = "com.mysql.cj.jdbc.Driver";
	private final static String db = "jdbc:mysql://localhost:3306/school";
	private final static String user = "root";
	private final static String pass = "";
	
	private Connection cn;
	private Statement st;
	
	public DBmanagement() {
		try{
			Class.forName(driver);
			cn = DriverManager.getConnection(db,user,pass);
			st = cn.createStatement();
			System.out.println("Conexion exitosa");
				} 
		
		catch (Exception e) {
			System.out.println("Conexion fallida: "+ e);
		}
		
	}
	
}

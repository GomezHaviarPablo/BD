package schooljava;

public class Profiles {
	private int id;
	private String description; 
	private int id_users;
	private int id_cities;
	public Profiles (int id, String description, int id_users, int id_cities) {
		this.setId(id);
		this.setDescription(description);
		this.setId_users(id_users);
		this.setId_cities(id_cities);
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getId_users() {
		return id_users;
	}
	public void setId_users(int id_users) {
		this.id_users = id_users;
	}
	public int getId_cities() {
		return id_cities;
	}
	public void setId_cities(int id_cities) {
		this.id_cities = id_cities;
	}
}

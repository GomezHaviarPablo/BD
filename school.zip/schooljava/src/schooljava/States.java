package schooljava;

public class States {
	private int id;
	private String name; 
	private int id_countries;
	public States (int id, String name, int id_countries) {
		this.setId(id);
		this.setName(name);
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	public int getId_countries() {
		return id_countries;
	}
	public void setId_countries(int id_countries) {
		this.id_countries = id_countries;
	}
}

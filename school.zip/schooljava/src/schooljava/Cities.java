package schooljava;

public class Cities {
	private int id;
	private String name; 
	private int id_states;
	
	
	public Cities (int id, String name, int id_states) {
		this.setId(id);
		this.setName(name);
	}
	
	

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	public int getId_states() {
		return id_states;
	}
	public void setId_states(int id_states) {
		this.id_states = id_states;
	}
}

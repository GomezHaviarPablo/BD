package schooljava;

//import java.util.Scanner;


public class Main {
	public static void main(String[] args) {
		Countries countries1 = new Countries (1, "Argentina");
		States states1 = new States (1,"Buenos Aires",1);
		Cities cities1 = new Cities (1,"Mar Del Plata",1);
		Users users1 = new Users (1, "Pablo", "Gomez", "1243","example@gmail.com");
		Profiles profiles1 = new Profiles (1, "Alumno", 1, 1);
		
		//string name;
		//string apellido;
		//Scanner leer = new Scanner(System.in);
		//System.out.println("Ingrese su nombre");
		//nombre = leer.next();
		//System.out.println("Ingrese su apellido");
		//apellido = leer.next();
		//Person objpersona = new Person(nombre,apellido);

		
		System.out.println(countries1.getId()+", "+countries1.getName());
		System.out.println(states1.getId()+", "+states1.getName());
		System.out.println(cities1.getId()+", "+cities1.getName());
		System.out.println(users1.getId()+", "+users1.getName()+", "+users1.getLastname()+", "+users1.getEmail()+", "+users1.getPassword());
		System.out.println(profiles1.getId()+", "+profiles1.getDescription());
		
		//DBmanagement db = new DBmanagement();
		
		
	}
}
